const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json()); // ✅ Preferred over body-parser

// MongoDB Connection
mongoose.connect("mongodb://127.0.0.1:27017/NitLink", {
  // useNewUrlParser and useUnifiedTopology are optional in latest Mongoose
}).then(() => {
  console.log("✅ MongoDB connected");
}).catch(err => {
  console.error("❌ MongoDB error:", err);
});

// Student Schema
const studentSchema = new mongoose.Schema({
  name: String,
  rollNumber: String,
  branch: String,
  email: String,
  password: String
});

const Student = mongoose.model("Student", studentSchema);

// Signup Route
app.post("/signup", async (req, res) => {
  console.log("📥 Received signup data:", req.body); // 👈 Log body for debugging

  const { name, rollNumber, branch, email, password } = req.body;

  // Check for missing fields
  if (!name || !rollNumber || !branch || !email || !password) {
    return res.status(400).json({ message: "Please fill all fields." });
  }

  try {
    const student = new Student({ name, rollNumber, branch, email, password });
    await student.save();
    res.status(200).json({ message: "Signup successful" });
  } catch (err) {
    console.error("❌ Error saving student:", err);
    res.status(500).json({ message: "Signup failed", error: err.message });
  }
});

// Start Server
app.listen(3000, () => {
  console.log("🚀 Server running at http://localhost:3000");
});
