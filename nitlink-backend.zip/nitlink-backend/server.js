const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

// ✅ MongoDB Connection
mongoose.connect("mongodb://127.0.0.1:27017/NitLink")
  .then(() => console.log("✅ MongoDB connected"))
  .catch(err => console.error("❌ MongoDB error:", err));

// ✅ Student Schema & Model
const studentSchema = new mongoose.Schema({
  name: String,
  rollNumber: String,
  branch: String,
  email: String,
  password: String
});
const Student = mongoose.model("Student", studentSchema);

// ✅ Event Schema & Model
const eventSchema = new mongoose.Schema({
  title: String,
  description: String,
  date: String,
  time: String,
  imageUrl: String // Optional
});
const Event = mongoose.model("Event", eventSchema);

// ✅ Student Signup
app.post("/signup", async (req, res) => {
  const { name, rollNumber, branch, email, password } = req.body;

  if (!name || !rollNumber || !branch || !email || !password) {
    return res.status(400).json({ message: "Please fill all fields." });
  }

  try {
    const existing = await Student.findOne({ email });
    if (existing) {
      return res.status(409).json({ message: "Email already registered" });
    }

    const student = new Student({ name, rollNumber, branch, email, password });
    await student.save();
    res.status(200).json({ message: "Signup successful" });
  } catch (err) {
    res.status(500).json({ message: "Signup failed", error: err.message });
  }
});

// ✅ Student Login
app.post("/login", async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: "Email and password are required" });
  }

  try {
    const student = await Student.findOne({ email });

    if (!student) {
      return res.status(404).json({ message: "User not found" });
    }

    if (student.password !== password) {
      return res.status(401).json({ message: "Incorrect password" });
    }

    res.status(200).json({ name: student.name });
  } catch (err) {
    res.status(500).json({ message: "Login failed", error: err.message });
  }
});

// ✅ Get User Info by Email
app.post("/getUser", async (req, res) => {
  const { email } = req.body;

  if (!email) {
    return res.status(400).json({ message: "Email is required" });
  }

  try {
    const student = await Student.findOne({ email });

    if (!student) {
      return res.status(404).json({ message: "User not found" });
    }

    res.status(200).json({
      name: student.name,
      rollNumber: student.rollNumber,
      branch: student.branch,
      email: student.email
    });
  } catch (err) {
    res.status(500).json({ message: "Error fetching user", error: err.message });
  }
});

// ✅ POST: Admin uploads an event
app.post("/events", async (req, res) => {
  const { title, description, date, time, imageUrl } = req.body;

  if (!title || !description || !date || !time) {
    return res.status(400).json({ message: "All fields except imageUrl are required" });
  }

  try {
    const event = new Event({ title, description, date, time, imageUrl });
    await event.save();
    res.status(200).json({ message: "Event uploaded successfully" });
  } catch (err) {
    res.status(500).json({ message: "Event upload failed", error: err.message });
  }
});

// ✅ GET: Fetch all events
app.get("/events", async (req, res) => {
  try {
    const events = await Event.find().sort({ date: 1 }); // sorted by date
    res.status(200).json(events);
  } catch (err) {
    res.status(500).json({ message: "Error fetching events", error: err.message });
  }
});

// ✅ Start the Server
app.listen(3000, () => {
  console.log("🚀 Server running at http://localhost:3000");
});
