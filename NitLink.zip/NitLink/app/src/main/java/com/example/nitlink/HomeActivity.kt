package com.example.nitlink

import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val userEmail = intent.getStringExtra("USER_EMAIL")
        val userName = intent.getStringExtra("USER_NAME") ?: "User"

        // Set greeting
        val greetingText = findViewById<TextView>(R.id.greetingText)
        greetingText.text = "Hi, $userName!"

        // Bottom nav (use LinearLayout not ImageButton)
        val homeBtn = findViewById<LinearLayout>(R.id.home_button)
        val clubsBtn = findViewById<LinearLayout>(R.id.clubs_button)
        val internshipBtn = findViewById<LinearLayout>(R.id.internship_button)
        val profileBtn = findViewById<LinearLayout>(R.id.profile_button)

        homeBtn.setOnClickListener {
            Toast.makeText(this, "Already on Home", Toast.LENGTH_SHORT).show()
        }

        clubsBtn.setOnClickListener {
            Toast.makeText(this, "Clubs clicked", Toast.LENGTH_SHORT).show()
        }

        internshipBtn.setOnClickListener {
            Toast.makeText(this, "Internship clicked", Toast.LENGTH_SHORT).show()
        }

        profileBtn.setOnClickListener {
            if (userEmail != null) {
                val profileIntent = Intent(this, ProfileActivity::class.java)
                profileIntent.putExtra("USER_EMAIL", userEmail)
                startActivity(profileIntent)
            } else {
                Toast.makeText(this, "User email not available", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
