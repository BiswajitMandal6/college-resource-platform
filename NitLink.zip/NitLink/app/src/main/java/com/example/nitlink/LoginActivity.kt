package com.example.nitlink

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val emailEditText = findViewById<EditText>(R.id.loginEmailEditText)
        val passwordEditText = findViewById<EditText>(R.id.loginPasswordEditText)
        val loginButton = findViewById<Button>(R.id.loginButton)
        val goToSignup = findViewById<TextView>(R.id.goToSignupText)

        loginButton.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter email and password", Toast.LENGTH_SHORT).show()
            } else {
                val url = "http://192.168.126.106:3000/login" // Replace with your actual server IP
                val queue = Volley.newRequestQueue(this)

                val jsonBody = """
                    {
                        "email": "$email",
                        "password": "$password"
                    }
                """.trimIndent()

                val request = object : StringRequest(Method.POST, url,
                    { response ->
                        try {
                            val name = JSONObject(response).getString("name")
                            Toast.makeText(this, "✅ Login Success", Toast.LENGTH_SHORT).show()

                            // Navigate to Home and pass name
                            val intent = Intent(this, HomeActivity::class.java)
                            intent.putExtra("USER_NAME", name)
                            intent.putExtra("USER_EMAIL", email) // assuming you have the email variable from login
                            startActivity(intent)
                            finish()

                        } catch (e: Exception) {
                            Toast.makeText(this, "Invalid response", Toast.LENGTH_SHORT).show()
                        }
                    },
                    { error ->
                        Toast.makeText(this, "❌ Login Failed: ${error.message}", Toast.LENGTH_LONG).show()
                    }
                ) {
                    override fun getBody(): ByteArray {
                        return jsonBody.toByteArray(Charsets.UTF_8)
                    }

                    override fun getBodyContentType(): String {
                        return "application/json; charset=utf-8"
                    }
                }

                queue.add(request)
            }
        }

        goToSignup.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}
