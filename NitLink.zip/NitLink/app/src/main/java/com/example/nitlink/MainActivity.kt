package com.example.nitlink

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val nameEditText = findViewById<EditText>(R.id.nameEditText)
        val rollEditText = findViewById<EditText>(R.id.rollEditText)
        val branchEditText = findViewById<EditText>(R.id.branchEditText)
        val emailEditText = findViewById<EditText>(R.id.emailEditText)
        val passwordEditText = findViewById<EditText>(R.id.passwordEditText)
        val signupButton = findViewById<Button>(R.id.loginButton)
        val goToLoginText = findViewById<TextView>(R.id.goToLoginText) // 👈 Add this to XML if missing

        signupButton.setOnClickListener {
            val name = nameEditText.text.toString().trim()
            val roll = rollEditText.text.toString().trim()
            val branch = branchEditText.text.toString().trim()
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()

            if (name.isEmpty() || roll.isEmpty() || branch.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val url = "http://192.168.126.106:3000/signup"
            val queue = Volley.newRequestQueue(this)

            val jsonBody = """
                {
                    "name": "$name",
                    "rollNumber": "$roll",
                    "branch": "$branch",
                    "email": "$email",
                    "password": "$password"
                }
            """.trimIndent()

            val request = object : StringRequest(
                Method.POST, url,
                { response ->
                    val jsonResponse = JSONObject(response)
                    if (jsonResponse.has("message")) {
                        Toast.makeText(this, "Signup successful. Please login.", Toast.LENGTH_SHORT).show()

                        // Clear fields
                        nameEditText.text.clear()
                        rollEditText.text.clear()
                        branchEditText.text.clear()
                        emailEditText.text.clear()
                        passwordEditText.text.clear()
                    } else {
                        Toast.makeText(this, "Signup failed.", Toast.LENGTH_SHORT).show()
                    }
                },
                { error ->
                    Toast.makeText(this, "❌ Signup Failed: ${error.message}", Toast.LENGTH_LONG).show()
                }
            ) {
                override fun getBody(): ByteArray {
                    return jsonBody.toByteArray(Charsets.UTF_8)
                }

                override fun getBodyContentType(): String {
                    return "application/json; charset=utf-8"
                }
            }

            queue.add(request)
        }

        // 👇 Navigate to login screen if user already has an account
        goToLoginText.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
        }
    }
}
