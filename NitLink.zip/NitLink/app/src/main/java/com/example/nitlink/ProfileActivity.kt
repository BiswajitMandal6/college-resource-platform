package com.example.nitlink

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException

class ProfileActivity : AppCompatActivity() {

    private val client = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val nameText = findViewById<TextView>(R.id.nameText)
        val emailText = findViewById<TextView>(R.id.emailText)
        val rollNumberText = findViewById<TextView>(R.id.rollNumberText)
        val branchText = findViewById<TextView>(R.id.branchText)
        val logoutButton = findViewById<Button>(R.id.logoutButton)

        val userEmail = intent.getStringExtra("USER_EMAIL")

        if (userEmail != null) {
            fetchUserData(userEmail, nameText, emailText, rollNumberText, branchText)
        } else {
            Toast.makeText(this, "No email found", Toast.LENGTH_SHORT).show()
        }

        logoutButton.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
        }
    }

    private fun fetchUserData(
        email: String,
        nameView: TextView,
        emailView: TextView,
        rollView: TextView,
        branchView: TextView
    ) {
        val url = "http://10.0.2.2:3000/getUser"
        val json = JSONObject().apply {
            put("email", email)
        }

        val JSON = "application/json; charset=utf-8".toMediaTypeOrNull()
        val requestBody = json.toString().toRequestBody(JSON)

        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Toast.makeText(this@ProfileActivity, "Failed to load profile", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                if (response.isSuccessful) {
                    val responseData = response.body?.string()
                    responseData?.let {
                        val user = JSONObject(it)
                        runOnUiThread {
                            nameView.text = user.optString("name", "N/A")
                            emailView.text = user.optString("email", "N/A")
                            rollView.text = user.optString("rollNumber", "N/A")
                            branchView.text = user.optString("branch", "N/A")
                        }
                    }
                } else {
                    runOnUiThread {
                        Toast.makeText(this@ProfileActivity, "Error loading profile", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        })
    }
}
